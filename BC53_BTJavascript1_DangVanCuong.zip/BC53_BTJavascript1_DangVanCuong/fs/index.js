var name = 'BT Javascript'
console.log('Bài Tập: ', name);

var BT1 = 'Tính tiền lương nhân viên'
console.log('BT1: ', BT1);
// B1: Input
var luongMotNgay = 100000;
var soNgayLam = 28;
var tienLuong;
// B2: Công Thức Tính
tienLuong = luongMotNgay * soNgayLam;
// B3: Xuất Dữ Liệu
console.log('Lương 01 Ngày: ', luongMotNgay);
console.log('Số Ngày Làm: ', soNgayLam);
console.log('Số Tiền Lương Là: ', tienLuong);

var BT2 = 'Tính giá trị trung bình'
console.log('BT2: ', BT2);
// B1: Input
var n1 = 5;
var n2 = 4;
var n3 = 5;
var n4 = 4;
var n5 = 5;
var giaTriTrungBinh
// B2: Công Thức Tính
giaTriTrungBinh = (n1 + n2 + n3 + n4 + n5) / 5
// B3: Xuất Dữ Liệu
console.log('n1 là: ', n1);
console.log('n2 là: ', n2);
console.log('n3 là: ', n3);
console.log('n4 là: ', n4);
console.log('n5 là: ', n5);
console.log('Giá Trị Trung Bình Là: ', giaTriTrungBinh);

var BT3 = 'Quy Đổi Tiền'
console.log('BT3: ', BT3);
// B1: Input
var usd = 5;
var heSoQuyDoi = 23500;
var vnd;
// B2: Công Thức Tính
vnd = usd * heSoQuyDoi;
// B3: Xuất Dữ Liệu
console.log('Khi USD bằng: ', usd);
console.log('VND là: ', vnd);
console.log(currency(vnd, {symbol: "đ"}).format())
var BT4 = 'Tính Diện Tích, Chi Vi Hình Chữ Nhật'
console.log('BT4: ', BT4);
// B1: Input
var chieuDai = 10;
var chieuRong = 5;
var dienTich;
var chuVi;
// B2: Công Thức Tính
dienTich = chieuDai * chieuRong;
chuVi = (chieuDai + chieuRong) * 2;
// B3: Xuất Dữ Liệu
console.log('Chiều Dài Bằng: ', chieuDai);
console.log('Chiều Rộng Bằng: ', chieuRong);
console.log('Diện Tích Là: ', dienTich);
console.log('Chu Vi Là: ', chuVi);

var BT5 = 'Tính Tổng 2 Ký Số'
console.log('BT5: ', BT5);
// B1: Input
var number = 83;
var soHangChuc;
var soHangDonVi;
var tongHaiKySo;
// B2: Công Thức Tính
soHangDonVi = number % 10;
soHangChuc = Math.floor(number / 10);
tongHaiKySo = soHangDonVi + soHangChuc;

// B3: Xuất Dữ Liệu
console.log('Khi Số Là: ', number);
console.log('Tổng Hai Ký Số Là: ', tongHaiKySo);